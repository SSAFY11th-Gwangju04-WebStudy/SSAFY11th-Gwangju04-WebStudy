package com.ssafy.user.model.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.user.model.UserDto;
import com.ssafy.user.model.mapper.UserMapper;

@Service
public class UserServiceImpl implements UserService {

	private UserMapper userMapper;
	
//	public UserServiceImpl() {
//		super();
//	}

	public UserServiceImpl(UserMapper userMapper) {
		super();
		this.userMapper = userMapper;
	}

	@Override
	public int idCheck(String userId) throws Exception {
		return userMapper.idCheck(userId);
	}

	@Override
	public void joinUser(UserDto userDto) throws Exception {
		System.out.println(userDto.getUserId());
		System.out.println(userDto.getUserName());
		System.out.println(userDto.getUserPass());
		userMapper.joinUser(userDto);
	}

	@Override
	public UserDto loginUser(Map<String, String> map) throws Exception {
		System.out.println(map.get("userid"));
		System.out.println(map.get("userpass"));
		return userMapper.loginUser(map);
	}

}
