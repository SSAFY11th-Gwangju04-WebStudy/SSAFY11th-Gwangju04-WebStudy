package com.ssafy.movie.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.movie.model.MovieDto;
import com.ssafy.movie.model.mapper.MovieMapper;

@Service
public class MovieServiceImpl implements MovieService {

	private MovieMapper movieMapper;
	
//	public MovieServiceImpl() {
//		super();
//	}

	public MovieServiceImpl(MovieMapper movieMapper) {
		super();
		this.movieMapper = movieMapper;
	}

	@Override
	public void writeMovie(MovieDto movieDto) throws Exception {
		
		movieMapper.writeMovie(movieDto);
	}

	@Override
	public List<MovieDto> listMovie() throws Exception {
		return movieMapper.listMovie();
	}

	@Override
	public MovieDto getMovie(int movieId) throws Exception {
		return movieMapper.getMovie(movieId);
	}

	@Override
	public void modifyMovie(MovieDto movieDto) throws Exception {
		movieMapper.modifyMovie(movieDto);
	}

	@Override
	public void deleteMovie(int movieId) throws Exception {
		movieMapper.deleteMovie(movieId);
	}

}
