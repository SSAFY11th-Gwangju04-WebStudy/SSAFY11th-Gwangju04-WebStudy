package com.ssafy.movie.controller;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ssafy.movie.model.MovieDto;
import com.ssafy.movie.model.service.MovieService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/movie")
public class MovieController {
	
	private MovieService movieService;

	public MovieController(MovieService movieService) {
		super();
		this.movieService = movieService;
	}
	
	@GetMapping("/write")
	public String write() throws Exception {
		return "write";
	}
	
	@PostMapping("/write")
	@Transactional
	public String write(MovieDto movieDto, HttpSession session, RedirectAttributes redirectAttributes) throws Exception {
		movieService.writeMovie(movieDto);
		return "redirect:list";
	}
	
	@GetMapping("/list")
	public ModelAndView listMovie() throws Exception {
		ModelAndView mav = new ModelAndView();
		List<MovieDto> movies = movieService.listMovie();
		mav.addObject("movies", movies);
		mav.setViewName("list");
		return mav;
	}
	
	@GetMapping("/view")
	public String getMovie(@RequestParam("movieId") int movieId, Model model) throws Exception {
		MovieDto movieDto = movieService.getMovie(movieId);
		model.addAttribute("movie", movieDto);
		return "view";
	}
	
	@GetMapping("/modify")
	public String modifyMovie(@RequestParam("movieId") int movieId, Model model) throws Exception {
		MovieDto movieDto = movieService.getMovie(movieId);
		model.addAttribute("movie", movieDto);
		return "modify";
	}
	
	@PostMapping("/modify")
	@Transactional
	public String modifyMovie(MovieDto movieDto, RedirectAttributes redirectAttributes) throws Exception {
		movieService.modifyMovie(movieDto);
		return "redirect:list";
	}
	
	@GetMapping("/delete")
	@Transactional
	public String deleteMovie(@RequestParam("movieId") int movieId, RedirectAttributes redirectAttributes) throws Exception {
		movieService.deleteMovie(movieId);
		return "redirect:list";
	}
	
}
