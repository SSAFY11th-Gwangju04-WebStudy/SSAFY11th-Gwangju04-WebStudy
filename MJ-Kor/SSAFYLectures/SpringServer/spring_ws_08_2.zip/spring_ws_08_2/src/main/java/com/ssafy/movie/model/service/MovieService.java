package com.ssafy.movie.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.movie.model.MovieDto;

@Service
public interface MovieService {
	
//	C
	void writeMovie(MovieDto movieDto) throws Exception;
	
//	R
	List<MovieDto> listMovie() throws Exception;
	MovieDto getMovie(int movieId) throws Exception;
	
//	U
	void modifyMovie(MovieDto movieDto) throws Exception;
	
//	D
	void deleteMovie(int movieId) throws Exception;
	
}
