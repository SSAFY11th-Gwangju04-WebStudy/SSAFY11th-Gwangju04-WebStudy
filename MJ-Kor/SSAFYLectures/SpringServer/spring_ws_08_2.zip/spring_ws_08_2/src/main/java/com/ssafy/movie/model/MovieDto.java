package com.ssafy.movie.model;

public class MovieDto {
	private int movieId;
	private String movieTitle;
	private String movieDirector;
	private String movieGenre;
	private int movieRunningTime;
	private String movieImg;
	
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public String getMovieDirector() {
		return movieDirector;
	}
	public void setMovieDirector(String movieDirector) {
		this.movieDirector = movieDirector;
	}
	public String getMovieGenre() {
		return movieGenre;
	}
	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}
	public int getMovieRunningTime() {
		return movieRunningTime;
	}
	public void setMovieRunningTime(int movieRunningTime) {
		this.movieRunningTime = movieRunningTime;
	}
	public String getMovieImg() {
		return movieImg;
	}
	public void setMovieImg(String movieImg) {
		this.movieImg = movieImg;
	}
	
	
}
