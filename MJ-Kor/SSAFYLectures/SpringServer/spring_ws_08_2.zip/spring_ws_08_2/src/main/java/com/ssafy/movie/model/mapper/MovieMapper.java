package com.ssafy.movie.model.mapper;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.movie.model.MovieDto;

@Mapper
public interface MovieMapper {
	
//	C
	void writeMovie(MovieDto movieDto) throws SQLException;
	
//	R
	List<MovieDto> listMovie() throws SQLException;
	MovieDto getMovie(int movieId) throws SQLException;
	
//	U
	void modifyMovie(MovieDto movieDto) throws SQLException;
	
//	D
	void deleteMovie(int movieId) throws SQLException;
	
}
