package com.ssafy.mtest.controller;

import java.net.http.HttpRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.mtest.model.UserDto;
import com.ssafy.mtest.service.UserService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/user")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	private final UserService userService;
	
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping("/login")
	public String loginForm() {
		return "login";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("loginUser");
		return "redirect:/";
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute UserDto userDto, HttpSession session, Model model) {
		
		logger.info("insert user={}", userDto);
		
		UserDto user = userService.login(userDto);
		
		logger.info("login user={}", user);
		
		if (user == null) {
			model.addAttribute("msg", "로그인 실패!");
		} else {
			session.setAttribute("loginUser", user);
			logger.info("세션확인 user={}", session.getAttribute("loginUser"));
		}
		
		
		return "index";
	}
}
