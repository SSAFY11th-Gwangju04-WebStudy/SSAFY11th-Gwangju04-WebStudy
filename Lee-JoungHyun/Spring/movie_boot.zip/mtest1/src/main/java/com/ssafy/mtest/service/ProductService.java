package com.ssafy.mtest.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ssafy.mtest.model.ProductDto;
import com.ssafy.mtest.model.ProductMapper;

@Service
public class ProductService {
	
	private final ProductMapper productMapper;

	public ProductService(ProductMapper productMapper) {
		this.productMapper = productMapper;
	}
	
	public List<ProductDto> showAll() {
		try {
			List<ProductDto> list = productMapper.findAll();
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public List<ProductDto> findById(String id) {
		try {
			List<ProductDto> list = productMapper.findById(id);
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean insert(ProductDto product) {
		try {
			productMapper.insert(product);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean update(ProductDto product) {
		try {
			productMapper.update(product);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public ProductDto findByCode(String code) {
		try {
			return productMapper.findByCode(code);
		} catch (SQLException e) {
			// TODO: handle exception
			return null;
		}
	}
	
	public void delete(String code) {
		try {
			productMapper.delete(code);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}
	
	public List<ProductDto> search(String id, String date) {
		Map<String, String> map = new HashMap();
		map.put("id", id);
		map.put("date", date);
		
		
		try {
			List<ProductDto> list = productMapper.search(map);
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		
	}

}
