package com.ssafy.mtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mtest1Application {

	public static void main(String[] args) {
		SpringApplication.run(Mtest1Application.class, args);
	}

}
