package com.ssafy.mtest.model;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {
	public UserDto login(UserDto user);
}
