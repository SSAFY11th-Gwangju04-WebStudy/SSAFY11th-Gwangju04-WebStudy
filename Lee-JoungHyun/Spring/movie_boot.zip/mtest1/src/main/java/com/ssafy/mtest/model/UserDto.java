package com.ssafy.mtest.model;

import java.sql.Timestamp;

public class UserDto {
	private String id;
	private String name;
	private String password;
	private Timestamp join_date;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Timestamp getTimestamp() {
		return join_date;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.join_date = timestamp;
	}
	
	@Override
	public String toString() {
		return "UserDto [id=" + id + ", name=" + name + ", password=" + password + ", join_date=" + join_date + "]";
	}
	

	
}
