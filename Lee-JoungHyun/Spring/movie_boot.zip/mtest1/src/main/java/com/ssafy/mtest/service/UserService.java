package com.ssafy.mtest.service;

import org.springframework.stereotype.Service;

import com.ssafy.mtest.model.UserDto;
import com.ssafy.mtest.model.UserMapper;

import lombok.RequiredArgsConstructor;

@Service
public class UserService {
	
	private final UserMapper userMapper;
	
	public UserService(UserMapper userMapper) {
		super();
		this.userMapper = userMapper;
	}

	public UserDto login(UserDto userDto) {
		UserDto user = userMapper.login(userDto);
		return user;
	}

}
