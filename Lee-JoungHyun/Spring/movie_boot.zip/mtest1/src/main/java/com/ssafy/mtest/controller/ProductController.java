package com.ssafy.mtest.controller;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonCreator.Mode;
import com.ssafy.mtest.model.ProductDto;
import com.ssafy.mtest.model.UserDto;
import com.ssafy.mtest.service.ProductService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductController {
	
	private final ProductService productService;
	
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

	public ProductController(ProductService productService) {
		super();
		this.productService = productService;
	}

	@GetMapping("/list")
	public ModelAndView showlist(ModelAndView mav, HttpSession session) {
		
		UserDto user = (UserDto) session.getAttribute("loginUser");
		List<ProductDto> list = null;
		if (user.getId().equals("admin")) {
			list = productService.showAll();
		} else {
			list = productService.findById(user.getId());
		}
		
		mav.addObject("products", list);
		mav.setViewName("list");
		return mav;
	}
	
	@GetMapping("/regist")
	public String showRegist() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public String regist(@ModelAttribute ProductDto product, HttpSession session) {
		product.setId(((UserDto) session.getAttribute("loginUser")).getId());
		logger.info("상품 = {}", product);
		productService.insert(product);
		return "redirect:/product/list";
	}
	
	@GetMapping("/edit/{code}")
	public ModelAndView details(@PathVariable String code, ModelAndView mav) {
		
		mav.addObject("product", productService.findByCode(code));
		mav.setViewName("detail");
	
		return mav;
	}
	
	@GetMapping("/update/{code}")
	public String editForm(@PathVariable String code, Model model) {
		
		ProductDto product = productService.findByCode(code);
		model.addAttribute("product", product);
		return "editForm";
	}
	
	@PostMapping("/update")
	public String editForm(@ModelAttribute ProductDto product) {
		productService.update(product);
		return "redirect:/product/edit/" + product.getCode();
	}
	
	@GetMapping("/delete/{code}")
	public String delete(@PathVariable String code) {
		productService.delete(code);
		return "redirect:/product/list";
	}
	
	@GetMapping("/search")
	public String searchDate(@RequestParam String searchDate, HttpSession session, Model model) {
		logger.info("date ={}", searchDate);
		List<ProductDto> list = productService.search(((UserDto) session.getAttribute("loginUser")).getId(), searchDate);
		
		model.addAttribute("products", list);
		return "list";
	}
}
