package com.ssafy.mtest.model;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductMapper {
	public List<ProductDto> findAll() throws SQLException;
	public List<ProductDto> findById(String id) throws SQLException;
	public void insert(ProductDto product) throws SQLException;
	public ProductDto findByCode(String code) throws SQLException;
	public void update(ProductDto product) throws SQLException;
	public List<ProductDto> search(Map<String, String> map) throws SQLException;
	public void delete(String code) throws SQLException;
}
