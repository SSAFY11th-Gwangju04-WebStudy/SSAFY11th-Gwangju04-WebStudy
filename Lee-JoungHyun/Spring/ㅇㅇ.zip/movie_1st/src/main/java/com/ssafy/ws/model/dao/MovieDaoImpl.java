package com.ssafy.ws.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.ws.model.dto.Movie;
import com.ssafy.ws.model.mapper.MovieMapper;

@Repository
public class MovieDaoImpl implements MovieDao {
	
	@Autowired
	MovieMapper mapper;

	@Override
	public List<Movie> showAll() {
		try {
			List<Movie> tmp = mapper.showAll();
			System.out.println(tmp);
			return tmp;
		} catch (SQLException e) {
			// TODO: handle exception
			return null;
		}
	}

	@Override
	public Movie show(int ID) {
		try {
			Movie m = mapper.show(ID);
			return m;
		} catch (SQLException e) {
			// TODO: handle exception
		}
		return null;
	}

	@Override
	public boolean delete(int ID) {
		try {
			mapper.delete(ID);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}
		
	}

	@Override
	public Movie insert(Movie movie) {
		try {
			mapper.regist(movie);
			return movie;
		} catch (SQLException e) {
			// TODO: handle exception
		}
		return null;
	}

	@Override
	public Movie update(Movie movie) {
		// TODO Auto-generated method stub
		try {
			mapper.update(movie);
			return movie;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
