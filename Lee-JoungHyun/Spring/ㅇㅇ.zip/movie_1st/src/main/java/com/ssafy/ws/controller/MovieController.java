package com.ssafy.ws.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.ws.model.dto.Movie;
import com.ssafy.ws.service.MovieService;

@Controller
public class MovieController {

	@Autowired
	MovieService movieService;
	
	@Autowired
	ResourceLoader resLoader;
	
	@GetMapping("/list")
	public ModelAndView showAll(ModelAndView mav) {
		mav.addObject("movies", movieService.showAll());
		mav.setViewName("list");
		return mav;
	}
	
	@GetMapping("/regist")
	public String save() {
		return "regist";
	}
	
	@PostMapping("/regist")
	public ModelAndView result(@ModelAttribute Movie movie, @RequestPart(value = "file", required = false) @RequestParam("file") MultipartFile file, ModelAndView mav)
			throws IllegalStateException, IOException {
		if (file != null && file.getSize() > 0) {
			// 파일을 저장할 폴더 지정
			Resource res = resLoader.getResource("WEB-INF/resources/upload");
			// 파일이 비어있다면 처리할 필요가 없다.
			// prefix를 포함한 전체 이름
			movie.setImg(System.currentTimeMillis() + "_" + file.getOriginalFilename());
			movie.setOrgImg(file.getOriginalFilename());

			file.transferTo(new File(res.getFile().getCanonicalPath() + "/" + movie.getImg()));
		}

		Movie m = movieService.insert(movie);
		mav.addObject("movie", m);
		mav.setViewName("regist_result");
		return mav;
	}
	
	@GetMapping("/details/{id}") 
	public ModelAndView details(@PathVariable int id, ModelAndView mav) {
		Movie m = movieService.show(id);
		mav.addObject("movie", m);
		mav.setViewName("details");
		return mav;
	}
	
	@GetMapping("/delete/{id}") 
	public String delete(@PathVariable int id) {
		movieService.delete(id);
		return "redirect:/list";
	}
	
	@GetMapping("/update/{id}")
	public ModelAndView edit(@PathVariable int id, ModelAndView mav) {
		Movie m = movieService.show(id);
		mav.addObject("movie", m);
		mav.setViewName("update");
		return mav;
	}
	
	@PostMapping("/update")
	public ModelAndView update(@ModelAttribute Movie movie, @RequestPart(value = "file", required = false) @RequestParam("file") MultipartFile file, ModelAndView mav)
			throws IllegalStateException, IOException {
		System.out.println("여기 시발아");
		if (file != null && file.getSize() > 0) {
			// 파일을 저장할 폴더 지정
			Resource res = resLoader.getResource("WEB-INF/resources/upload");
			// 파일이 비어있다면 처리할 필요가 없다.
			// prefix를 포함한 전체 이름
			movie.setImg(System.currentTimeMillis() + "_" + file.getOriginalFilename());
			movie.setOrgImg(file.getOriginalFilename());

			file.transferTo(new File(res.getFile().getCanonicalPath() + "/" + movie.getImg()));
		}
		
		Movie m = movieService.update(movie);
		mav.addObject("movie", m);
		mav.setViewName("regist_result");
		
		return mav;
	}
	
}
