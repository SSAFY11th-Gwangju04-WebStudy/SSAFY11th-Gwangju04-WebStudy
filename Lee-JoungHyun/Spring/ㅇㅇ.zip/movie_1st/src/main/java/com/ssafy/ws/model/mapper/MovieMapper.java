package com.ssafy.ws.model.mapper;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.ws.model.dto.Movie;

@Mapper
public interface MovieMapper {
	List<Movie> showAll() throws SQLException;
	void regist(Movie movie) throws SQLException;
	Movie show(int ID) throws SQLException;
	void delete(int ID) throws SQLException;
	void update(Movie movie) throws SQLException;
}
