package com.ssafy.ws.model.dao;

import java.sql.SQLException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.ws.model.dto.User;
import com.ssafy.ws.model.mapper.UserMapper;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private UserMapper userMapper;
	
	@Override
	@Transactional
	public boolean login(User user) throws SQLException {
		
		if (userMapper.login(user) == 1)
			return true;
		
		return false;
	}

}
