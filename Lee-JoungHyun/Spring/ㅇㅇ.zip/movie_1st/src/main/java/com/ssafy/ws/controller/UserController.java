package com.ssafy.ws.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.ws.model.dto.User;
import com.ssafy.ws.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;

	@RequestMapping("/login")
	public String doLogin(@ModelAttribute User user, HttpSession session, Model model) {
		
		if (userService.login(user)) {
			model.addAttribute("loginUser", user);
			session.setAttribute("loginUser", user);
		}
		else {
			model.addAttribute("msg", "로그인 실패!!");
		}
		
		return "index";
	}
	
	@RequestMapping("/logout")
	public String doLogOut(@ModelAttribute User user, HttpSession session, Model model) {
		userService.logout(session);
		return "redirect:/";
	}
}
