package com.ssafy.ws.model.dao;

import java.util.List;

import com.ssafy.ws.model.dto.Movie;

public interface MovieDao {
	public List<Movie> showAll();
	public Movie show(int ID);
	public boolean delete(int ID);
	public Movie insert(Movie movie);
	public Movie update(Movie movie);
}
