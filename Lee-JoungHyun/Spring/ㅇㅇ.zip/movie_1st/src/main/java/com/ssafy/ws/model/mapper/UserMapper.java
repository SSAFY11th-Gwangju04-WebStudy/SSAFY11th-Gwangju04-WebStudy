package com.ssafy.ws.model.mapper;

import java.sql.SQLException;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.ws.model.dto.User;

@Mapper
public interface UserMapper {
	public int login(User user) throws SQLException;
}
