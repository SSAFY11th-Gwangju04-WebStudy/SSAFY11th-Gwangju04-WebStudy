package com.ssafy.ws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ws.model.dao.MovieDao;
import com.ssafy.ws.model.dto.Movie;

@Service
public class MovieService {

	@Autowired
	MovieDao movieDao;
	
	public List<Movie> showAll() {
		return movieDao.showAll();
	}
	
	public Movie show(int ID) {
		return movieDao.show(ID);
	}
	
	public Movie insert(Movie movie) {
		return movieDao.insert(movie);
	}
	
	public void delete(int ID) {
		movieDao.delete(ID);
	}
	public Movie update(Movie movie) {
		return movieDao.update(movie);
	}
	
}
