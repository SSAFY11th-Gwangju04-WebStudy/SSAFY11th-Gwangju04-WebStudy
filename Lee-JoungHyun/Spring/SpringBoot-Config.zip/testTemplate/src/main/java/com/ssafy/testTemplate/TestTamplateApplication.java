package com.ssafy.testTemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestTamplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestTamplateApplication.class, args);
	}

}
