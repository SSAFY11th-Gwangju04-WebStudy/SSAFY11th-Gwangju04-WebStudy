package com.github.prgrms.products;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

import static com.google.common.base.Preconditions.checkArgument;
import static java.time.LocalDateTime.now;
import static org.apache.commons.lang3.ObjectUtils.defaultIfNull;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Getter
@Setter
@Builder
@Entity
@NoArgsConstructor
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seq;

    @Column
    private String name;

    @Column
    private String details;

    @Column(name = "review_count")
    private int reviewCount;

    @Column
    private LocalDateTime createAt;

    public Product(String name, String details) {
        this(null, name, details, 0, null);
    }

    public Product(Long seq, String name, String details, int reviewCount, LocalDateTime createAt) {
        checkArgument(isNotEmpty(name), "name must be provided");
        checkArgument(name.length() >= 1 && name.length() <= 50, "name length must be between 1 and 50 characters");
        checkArgument(isEmpty(details) || details.length() <= 1000, "details length must be less than 1000 characters");

        this.seq = seq;
        this.name = name;
        this.details = details;
        this.reviewCount = reviewCount;
        this.createAt = defaultIfNull(createAt, now());
    }

    public void writeReviewSuccess() {
        reviewCount++;
    }
}