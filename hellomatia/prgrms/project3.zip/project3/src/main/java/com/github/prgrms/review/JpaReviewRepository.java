package com.github.prgrms.review;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JpaReviewRepository extends JpaRepository<Review, Long> {

    Optional<Review> findByUserSeqAndProductSeq(Long userSeq, Long productSeq);

    Optional<Review> findById(Long id);
}
