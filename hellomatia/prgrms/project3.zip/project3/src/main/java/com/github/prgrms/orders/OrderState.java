package com.github.prgrms.orders;

import java.util.Arrays;

public enum OrderState {
    REQUESTED("REQUESTED"),
    ACCEPTED("ACCEPTED"),
    SHIPPING("SHIPPING"),
    COMPLETED("COMPLETED"),
    REJECTED("REJECTED");

    private final String state;

    OrderState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public static OrderState of(String state) {
        return Arrays.stream(values())
                .filter(value -> value.getState().equals(state))
                .findFirst()
                .orElse(null);
    }
}
