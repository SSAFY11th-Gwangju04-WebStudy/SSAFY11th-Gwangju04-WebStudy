package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import com.github.prgrms.security.JwtAuthentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.github.prgrms.utils.ApiUtils.ApiResult;
import static com.github.prgrms.utils.ApiUtils.success;

@RestController
@RequestMapping("api/orders")
public class OrderRestController {

    private final OrderService orderService;

    public OrderRestController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public ApiResult<List<OrderResult>> findAll(Pageable pageable,
                                                @AuthenticationPrincipal JwtAuthentication authentication) {
        List<OrderResult> results = orderService.findAll(pageable, authentication.id);
        return success(results);
    }

    @GetMapping("/{orderId}")
    public ApiResult<OrderResult> findById(@PathVariable Long orderId) {
        return success(orderService.findById(orderId));
    }

    @PatchMapping("/{orderId}/accept")
    public ApiResult accept(@PathVariable Long orderId) {
        return success(orderService.accept(orderId));
    }

    @PatchMapping("/{orderId}/reject")
    public ApiResult reject(@PathVariable Long orderId, @RequestBody Map<String, String> requestBody) {
        return success(orderService.reject(orderId, requestBody.get("message")));
    }

    @PatchMapping("/{orderId}/shipping")
    public ApiResult shipping(@PathVariable Long orderId) {
        return success(orderService.shipping(orderId));
    }

    @PatchMapping("/{orderId}/complete")
    public ApiResult complete(@PathVariable Long orderId) {
        return success(orderService.complete(orderId));
    }

}