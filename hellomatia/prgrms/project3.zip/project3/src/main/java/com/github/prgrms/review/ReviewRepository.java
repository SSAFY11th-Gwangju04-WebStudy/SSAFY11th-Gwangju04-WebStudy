package com.github.prgrms.review;

import java.util.Optional;

public interface ReviewRepository {

    Optional<Review> findByUserSeqAndProductSeq(Long userSeq, Long productSeq);

    Optional<Review> findById(long reviewId);
}
