package com.github.prgrms.configures.web;

public interface Pageable {

    long getOffset();

    int getSize();

}