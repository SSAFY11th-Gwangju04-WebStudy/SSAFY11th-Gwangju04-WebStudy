package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import com.github.prgrms.errors.NotFoundException;
import com.github.prgrms.review.JpaReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

@Service
@RequiredArgsConstructor
@Transactional
public class OrderService {

    private final JpaOrderRepository orderRepository;
    private final JpaReviewRepository reviewRepository;

    public List<OrderResult> findAll(Pageable pageable, long userId) {
        checkNotNull(pageable, "pageable cannot be null");
        List<Order> orders = orderRepository.findAllByUserId(pageable, userId);
        return orders.stream()
                .map(order -> new OrderResult(order, order.getReviewSeq() == null ?
                        null : reviewRepository.findById(order.getReviewSeq())
                        .orElseThrow(() -> new NotFoundException("Review not found"))))
                .collect(Collectors.toList());
    }

    public OrderResult findById(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(()
                -> new NotFoundException("Order not found"));

        return new OrderResult(order, order.getReviewSeq() == null ?
                null : reviewRepository.findById(order.getReviewSeq())
                .orElseThrow(() -> new NotFoundException("Review not found")));
    }

    public boolean accept(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.REQUESTED) {
            order.setState(OrderState.ACCEPTED);
            Order order1 = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));
            System.out.println(order.getState());
            System.out.println(order1.getState());
            return true;
        }
        return false;
    }

    public boolean reject(Long orderId, String message) {
        checkNotNull(orderId, "orderId cannot be null");
        checkNotNull(message, "message cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.REQUESTED) {
            order.rejectedSuccess(message);
            return true;
        }
        return false;
    }

    public boolean shipping(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.ACCEPTED) {
            order.setState(OrderState.SHIPPING);
            return true;
        }
        return false;
    }

    public boolean complete(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.SHIPPING) {
            order.completedSuccess();
            return true;
        }
        return false;
    }

}
