package com.github.prgrms.orders;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seq;

    @Column(name = "user_seq")
    private Long userSeq;

    @Column(name = "product_seq")
    private Long productSeq;

    @Column(name = "review_seq")
    private Long reviewSeq;

    @Column(name = "state")
    @Enumerated(EnumType.STRING)
    private OrderState state;

    @Column(name = "request_msg")
    private String requestMsg;

    @Column(name = "reject_msg")
    private String rejectMsg;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "rejected_at")
    private LocalDateTime rejectedAt;

    @Column(name = "create_at")
    private LocalDateTime createAt;

    public void writeReviewSuccess(Long reviewId) {
        this.reviewSeq = reviewId;
    }

    public void completedSuccess() {
        this.setState(OrderState.COMPLETED);
        completedAt = LocalDateTime.now();
    }

    public void rejectedSuccess(String msg) {
        this.setState(OrderState.REJECTED);
        rejectedAt = LocalDateTime.now();
        this.rejectMsg = msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return Objects.equals(seq, order.seq) && Objects.equals(userSeq, order.userSeq) && Objects.equals(productSeq, order.productSeq) && Objects.equals(reviewSeq, order.reviewSeq) && state == order.state && Objects.equals(requestMsg, order.requestMsg) && Objects.equals(rejectMsg, order.rejectMsg) && Objects.equals(completedAt, order.completedAt) && Objects.equals(rejectedAt, order.rejectedAt) && Objects.equals(createAt, order.createAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(seq, userSeq, productSeq, reviewSeq, state, requestMsg, rejectMsg, completedAt, rejectedAt, createAt);
    }

    @Override
    public String toString() {
        return "Order{" +
                "seq=" + seq +
                ", userSeq=" + userSeq +
                ", productSeq=" + productSeq +
                ", reviewSeq=" + reviewSeq +
                ", state=" + state +
                ", requestMsg='" + requestMsg + '\'' +
                ", rejectMsg='" + rejectMsg + '\'' +
                ", completedAt=" + completedAt +
                ", rejectedAt=" + rejectedAt +
                ", createAt=" + createAt +
                '}';
    }
}
