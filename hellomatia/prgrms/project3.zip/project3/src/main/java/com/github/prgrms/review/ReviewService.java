package com.github.prgrms.review;

import com.github.prgrms.errors.NotFoundException;
import com.github.prgrms.errors.ReviewNotAllowedException;
import com.github.prgrms.orders.JpaOrderRepository;
import com.github.prgrms.orders.Order;
import com.github.prgrms.orders.OrderState;
import com.github.prgrms.products.JpaProductRepository;
import com.github.prgrms.products.Product;
import com.github.prgrms.users.JpaUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ReviewService {

    private final JpaReviewRepository reviewRepository;
    private final JpaOrderRepository orderRepository;
    private final JpaProductRepository productRepository;
    private final JpaUserRepository userRepository;

    public Review createReview(long orderId, long userId, String reviewContent) {
        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        Long productId = order.getProductSeq();
        Product product = productRepository.findById(productId).orElseThrow(() -> new NotFoundException("Product not found"));

        if (reviewContent == null || reviewContent.isEmpty()) {
            throw new ReviewNotAllowedException("Review content is empty");
        }

        if (reviewContent.length() > 1000) {
            throw new ReviewNotAllowedException("Review content too long");
        }

        if (order.getState() != OrderState.COMPLETED) {
            throw new ReviewNotAllowedException("Could not write review for order "
                    + orderId + " because state(" + order.getState().getState() + ") is not allowed");
        }

        if (order.getReviewSeq() != null) {
            System.out.println(order.getReviewSeq());
            throw new ReviewNotAllowedException("Could not write review for order "
                    + orderId + " because have already written");
        }

        Review reviewData = Review.builder()
                .content(reviewContent)
                .productSeq(productId)
                .userSeq(userId)
                .build();

        reviewRepository.save(reviewData);

        Review saveData = reviewRepository.findByUserSeqAndProductSeq(userId, productId).orElseThrow(() -> new NotFoundException("Review not found"));
        product.writeReviewSuccess();

        order.writeReviewSuccess(saveData.getSeq());

        return saveData;
    }
}
