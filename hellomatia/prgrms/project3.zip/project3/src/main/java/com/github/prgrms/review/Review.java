package com.github.prgrms.review;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seq;

    @Column(name = "user_seq")
    private Long userSeq;

    @Column(name = "product_seq")
    private Long productSeq;

    @Column
    private String content;

    @Column(name = "create_at")
    private LocalDateTime createAt;
}
