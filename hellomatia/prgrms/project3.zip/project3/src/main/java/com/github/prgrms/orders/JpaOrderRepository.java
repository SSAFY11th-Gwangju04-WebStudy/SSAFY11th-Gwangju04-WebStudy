package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JpaOrderRepository extends JpaRepository<Order, Long> {

    Optional<Order> findById(Long id);

    @Query(value = "select * " +
            "from orders o " +
            "where o.user_seq = :userId " +
            "order by o.seq desc " +
            "limit :#{#pageable.offset}, :#{#pageable.size}",
            nativeQuery = true)
    List<Order> findAllByUserId(@Param("pageable") Pageable pageable, @Param("userId") Long userId);
}
