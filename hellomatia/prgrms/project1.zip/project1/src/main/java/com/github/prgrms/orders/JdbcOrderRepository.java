package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

import static java.util.Optional.ofNullable;

@Repository
public class JdbcOrderRepository implements OrderRepository {
    private final JdbcTemplate jdbcTemplate;

    public JdbcOrderRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Order> findAll(Pageable pageable) {
        List<Order> results = jdbcTemplate.query(
            "SELECT * FROM orders LIMIT ?, ?",
            mapper,
            id
          );
          return ofNullable(results.isEmpty() ? null : results.get(0));
    }

    public Order findById(Long id) {
        List<Order> results = jdbcTemplate.query(
            "SELECT * FROM orders WHERE id=?",
            mapper,
            id
          );
          return ofNullable(results.isEmpty() ? null : results.get(0));
    }

    public void update(Order order) {
        jdbcTemplate.update(
            "UPDATE orders SET status=?, created_at=?, created_by=?, accepted_at=?, accepted_by=?, shipping_at=?, shipping_by=?, completed_at=?, completed_by=?, rejected_reason=? WHERE id=?",
            order.getStatus(),
            order.getCreatedAt(),
            order.getCreatedBy(),
            order.getAcceptedAt(),
            order.getAcceptedBy(),
            order.getShippingAt(),
            order.getShippingBy(),
            order.getCompletedAt(),
            order.getCompletedBy(),
            order.getRejectedReason(),
            order.getId()
        );
    }

    private RowMapper<Order> mapper = (rs, rowNum) -> new Order(
        rs.getLong("id"),
        rs.getString("status"),
        rs.getTimestamp("created_at"),
        rs.getLong("created_by"),
        rs.getTimestamp("accepted_at"),
        rs.getLong("accepted_by"),
        rs.getTimestamp("shipping_at"),
        rs.getLong("shipping_by"),
        rs.getTimestamp("completed_at"),
        rs.getLong("completed_by"),
        rs.getString("rejected_reason")
    );
}
