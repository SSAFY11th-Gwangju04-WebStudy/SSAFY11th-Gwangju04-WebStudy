package com.github.prgrms.orders;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static com.github.prgrms.utils.DateTimeUtils.dateTimeOf;
import static java.util.Optional.ofNullable;

@Repository
public class JdbcReviewRepository implements ReviewRepository {

  private final JdbcTemplate jdbcTemplate;

  public JdbcReviewRepository(JdbcTemplate jdbcTemplate) {
    this.jdbcTemplate = jdbcTemplate;
  }

  @Override
  public int save(Review review) {
    return 0;
  }

  @Override
  public Optional<Review> findById(long id) {
    List<Review> results = jdbcTemplate.query(
      "SELECT * FROM reviews WHERE seq=?",
      mapper,
      id
    );
    return ofNullable(results.isEmpty() ? null : results.get(0));
  }

  @Override
  public List<Review> findByUserSeq(long userSeq) {
    return jdbcTemplate.query(
      "SELECT * FROM reviews WHERE user_seq=? ORDER BY seq DESC",
      mapper
    );
  }

  static RowMapper<Review> mapper = (rs, rowNum) ->
    new Review.Builder()
      .seq(rs.getLong("seq"))
      .userSeq(rs.getLong("user_seq"))
      .productSeq(rs.getLong("product_seq"))
      .content(rs.getString("content"))
      .createAt(dateTimeOf(rs.getTimestamp("create_at")))
      .build();
}

