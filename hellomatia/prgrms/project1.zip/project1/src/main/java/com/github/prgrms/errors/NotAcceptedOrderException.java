package com.github.prgrms.errors;

public class NotAcceptedOrderException extends RuntimeException {

    public NotAcceptedOrderException(String message) {
        super(message);
    }

    public NotAcceptedOrderException(String message, Throwable cause) {
        super(message, cause);
    }

}