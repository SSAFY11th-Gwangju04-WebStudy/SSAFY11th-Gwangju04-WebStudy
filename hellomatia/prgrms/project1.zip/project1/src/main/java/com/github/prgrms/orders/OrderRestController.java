package com.github.prgrms.orders;

import static com.github.prgrms.utils.ApiUtils.ApiResult;
import static com.github.prgrms.utils.ApiUtils.success;

import com.github.prgrms.configures.web.Pageable;
import com.github.prgrms.security.JwtAuthentication;
import com.github.prgrms.utils.ApiUtils;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/orders")
public class OrderRestController {
    // TODO findAll, findById, accept, reject, shipping, complete 메소드 구현이 필요합니다.

    private final OrderService orderService;

    public OrderRestController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public ApiResult<List<OrderDto>> findAll(@AuthenticationPrincipal JwtAuthentication authentication,
                                             @RequestParam(defaultValue = "0") Long offset,
                                             @RequestParam(defaultValue = "5") int size) {
    if (offset < 0) offset = 0L;
    if (size < 1) size = 1;
    else if (size > 5) size = 5;

    Pageable pageable = PageRequest.of((int) (offset / size), size);
    List<OrderDto> orders = orderService.findAll(pageable).stream()
            .map(OrderDto::new)
            .collect(Collectors.toList());

    return success(orders);
}

    @GetMapping("/{id}")
    public ApiResult<OrderDto> findById(@PathVariable Long id, @AuthenticationPrincipal JwtAuthentication authentication){
        return success(new OrderDto(orderService.findById(id)));
    }

    @PatchMapping("/{id}/accept")
    public ApiResult accept(@PathVariable Long id, @AuthenticationPrincipal JwtAuthentication authentication) {
        boolean result = orderService.acceptOrder(id, authentication.id);
        return success(result);
    }

    @PatchMapping("/{id}/reject")
    public ApiResult<Boolean> reject(@PathVariable Long id, @RequestBody Map<String, String> body, @AuthenticationPrincipal JwtAuthentication authentication) {
        String message = body.get("message");
        boolean result = orderService.rejectOrder(id, authentication.id, message);
        return success(result);
    }

    @PatchMapping("/{id}/shipping")
    public ApiResult shipping(@PathVariable Long id, @AuthenticationPrincipal JwtAuthentication authentication) {
        boolean result = orderService.shippingOrder(id, authentication.id);
        return success(result);
    }

    @PatchMapping("/{id}/complete")
    public ApiResult<Boolean> complete(@PathVariable Long id, @AuthenticationPrincipal JwtAuthentication authentication) {
        boolean result = orderService.completeOrder(id, authentication.id);
        return success(result);
    }
}