package com.github.prgrms.orders;

import com.github.prgrms.products.ProductService;
import com.github.prgrms.security.JwtAuthentication;
import com.github.prgrms.utils.ApiUtils;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.github.prgrms.utils.ApiUtils.success;

@RestController
@RequestMapping("api/orders")
public class ReviewRestController {
    // TODO review 메소드 구현이 필요합니다.


    private final ReviewService reviewService;
    private final ProductService productService;

    public ReviewRestController(ReviewService reviewService, ProductService productService) {
        this.reviewService = reviewService;
        this.productService = productService;
    }

    @PostMapping("/{id}/review")
    public ApiUtils.ApiResult<Review> review(@PathVariable Long id, @RequestBody Map<String, String> requestBody, @AuthenticationPrincipal JwtAuthentication authentication) {
        // 인증된 사용자의 ID를 가져옵니다.
        Long userId = authentication.id;
    
        // requestBody에서 리뷰 내용을 추출합니다.
        String content = requestBody.get("content");
    
        try {
            // 주문 상태를 확인하고, 리뷰 작성 가능 여부를 검사합니다.
            if (!orderService.canWriteReview(id, userId)) {
                // 주문 상태가 COMPLETED가 아니거나 이미 리뷰를 작성한 경우
                return ApiUtils.error("Could not write review for order " + id + " because state is not allowed or review already exists", 400);
            }
    
            // 리뷰 작성 로직을 구현합니다.
            Review review = reviewService.createReview(id, userId, content);
    
            // 리뷰 생성이 성공하면, 생성된 리뷰 정보를 포함하는 ApiResult를 반환합니다.
            return ApiUtils.success(review);
        } catch (Exception e) {
            // 리뷰 생성 중 오류가 발생한 경우, 적절한 오류 응답을 반환합니다.
            return ApiUtils.error("An error occurred while creating the review", 500);
        }
    }
}

/**
 * ReviewRestController.review 메소드를 구현하세요.

 인증된 사용자 본인의 주문에 대해 리뷰를 작성한다.

 주문 상태 state가 COMPLETED라면 리뷰를 작성할 수 있다. 단, 동일한 주문에 대해 중복 리뷰를 작성할 수 없다. 정상적으로 리뷰가 작성되면 리뷰 대상 Product의 reviewCount 값이 1 증가한다.

 리뷰 작성이 불가능하다면 400 오류를 응답한다.

 구분: 인증 사용자용 API
 구현 컨트롤러: com.github.prgrms.orders.ReviewRestController
 컨트롤러 메소드명: review
 URL: POST /api/orders/{id}/review

 {id}: 리뷰를 남기려는 주문의 PK
 Request Body: 리뷰 내용
 {
 "content": "review test"
 }
 Response Body: 작성된 리뷰 내용
 {
 "success": true,
 "response": {
 "seq": 2,
 "productId": 3,
 "content": "review test",
 "createAt": "2021-01-20 20:16:47"
 },
 "error": null
 }
 중복 리뷰 작성 오류 응답 예시
 {
 "success": false,
 "response": null,
 "error": {
 "message": "Could not write review for order 4 because have already written",
 "status": 400
 }
 }
 주문 상태 state가 COMPLETED가 아닌 경우 오류 응답 예시
 {
 "success": false,
 "response": null,
 "error": {
 "message": "Could not write review for order 1 because state(REQUESTED) is not allowed",
 "status": 400
 }
 }
 *
 *
 *
 *
 */