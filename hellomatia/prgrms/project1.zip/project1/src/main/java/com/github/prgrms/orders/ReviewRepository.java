package com.github.prgrms.orders;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReviewRepository {

    int save(Review review);

   Optional<Review> findById(long id);

   List<Review> findByUserSeq(long userSeq);
}
