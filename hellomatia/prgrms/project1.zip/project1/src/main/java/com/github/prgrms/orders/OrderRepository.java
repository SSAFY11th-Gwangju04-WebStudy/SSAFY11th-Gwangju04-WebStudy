package com.github.prgrms.orders;

import java.util.List;

public interface OrderRepository {
    List<Order> findAll(Pageable pageable);
    Order findById(Long id);
    void update(Order order);
}
