package com.github.prgrms.orders;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    
    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @Transactional
    public int createReview(Review review) {
        return reviewRepository.save(review);
    }

    @Transactional(readOnly = true)
    public Optional<Review> findReview(Long seq) {
        return reviewRepository.findById(seq);
    }

    @Transactional(readOnly = true)
    public List<Review> findReviewsByUserSeq(Long userSeq) {
        return reviewRepository.findByUserSeq(userSeq);
    }
}
