package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Order> findAll(Pageable pageable){
        return orderRepository.findAll(pageable);
    }

    public Order findById(Long id){
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id " + id));
    }

    public boolean acceptOrder(Long id, Long userId){
        Order order = findById(id);
        if(order.getStatus() != OrderStatus.ACCEPTED){
            throw new NotAcceptedOrderException("Order is not accepted");
        }
        order.setAcceptedAt(LocalDateTime.now());
        order.setAcceptedBy(userId);
        orderRepository.update(order);
        return true;
    }

    public boolean rejectOrder(Long id, Long userId, String message){
        Order order = findById(id);
        if(order.getStatus() != OrderStatus.ACCEPTED){
            throw new NotAcceptedOrderException("Order is not accepted");
        }
        order.setRejectedAt(LocalDateTime.now());
        order.setRejectedBy(userId);
        order.setRejectedReason(message);
        orderRepository.update(order);
        return true;
    }

    public boolean shippingOrder(Long id, Long userId){
        Order order = findById(id);
        if(order.getStatus() != OrderStatus.ACCEPTED){
            throw new NotAcceptedOrderException("Order is not accepted");
        }
        order.setShippingAt(LocalDateTime.now());
        order.setShippingBy(userId);
        orderRepository.update(order);
        return true;
    }

    public boolean completeOrder(Long id, Long userId){
        Order order = findById(id);
        if(order.getStatus() != OrderStatus.SHIPPING){
            throw new NotShippingOrderException("Order is not shipping");
        }
        order.setCompletedAt(LocalDateTime.now());
        orderRepository.update(order);
        return true;
    }
}
