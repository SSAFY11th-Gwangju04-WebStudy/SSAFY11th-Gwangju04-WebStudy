package com.github.prgrms.review;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static java.util.Optional.ofNullable;

@Repository
public class JdbcReviewRepository implements ReviewRepository {

    private final JdbcTemplate jdbcTemplate;

    public JdbcReviewRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public int saveReview(Review review) {
        return jdbcTemplate.update("insert into reviews(user_seq, product_seq, content) values(?, ?, ?)",
                review.getUserSeq(),
                review.getProductSeq(),
                review.getContent());
    }

    @Override
    public Optional<Review> findByUserIdAndProductId(long userId, long productId) {
        List<Review> results = jdbcTemplate.query("select * from reviews where user_seq = ? and product_seq = ?",
                mapper,
                userId,
                productId);
        return ofNullable(results.isEmpty() ? null : results.get(0));
    }

    @Override
    public Optional<Review> findById(long reviewId) {
        List<Review> results = jdbcTemplate.query("select * from reviews where seq = ?", mapper, reviewId);
        return ofNullable(results.isEmpty() ? null : results.get(0));
    }

    static RowMapper<Review> mapper = (rs, rowNum) ->
            new Review(
                    rs.getLong("seq"),
                    rs.getLong("user_seq"),
                    rs.getLong("product_seq"),
                    rs.getString("content"),
                    rs.getTimestamp("create_at").toLocalDateTime()
            );
}
