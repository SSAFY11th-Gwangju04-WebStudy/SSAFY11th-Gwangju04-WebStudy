package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import com.github.prgrms.errors.NotFoundException;
import com.github.prgrms.review.ReviewRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ReviewRepository reviewRepository;

    public OrderService(OrderRepository orderRepository, ReviewRepository reviewRepository) {
        this.orderRepository = orderRepository;
        this.reviewRepository = reviewRepository;
    }

    @Transactional(readOnly = true)
    public OrderResult findById(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(()
                -> new NotFoundException("Order not found"));

        return new OrderResult(order, order.getReviewSeq() == null ?
                null : reviewRepository.findById(order.getReviewSeq())
                .orElseThrow(() -> new NotFoundException("Review not found")));
    }

    public List<OrderResult> findAll(Pageable pageable, long userId) {
        checkNotNull(pageable, "pageable cannot be null");
        List<Order> orders = orderRepository.findAll(pageable, userId);
        return orders.stream()
                .map(order -> new OrderResult(order, order.getReviewSeq() == null ?
                        null : reviewRepository.findById(order.getReviewSeq())
                        .orElseThrow(() -> new NotFoundException("Review not found"))))
                .collect(Collectors.toList());
    }

    public boolean accept(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.REQUESTED) {
            order.setState(OrderState.ACCEPTED);
            orderRepository.update(order);
            return true;
        }
        return false;
    }

    public boolean reject(Long orderId, String message) {
        checkNotNull(orderId, "orderId cannot be null");
        checkNotNull(message, "message cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.REQUESTED) {
            order.setState(OrderState.REJECTED);
            order.rejectSuccess(message);
            orderRepository.update(order);
            return true;
        }
        return false;
    }

    public boolean shipping(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.ACCEPTED) {
            order.setState(OrderState.SHIPPING);
            orderRepository.update(order);
            return true;
        }
        return false;
    }

    public boolean complete(Long orderId) {
        checkNotNull(orderId, "orderId cannot be null");

        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        if (order.getState() == OrderState.SHIPPING) {
            order.completedSuccess();
            orderRepository.update(order);
            return true;
        }
        return false;
    }

}
