package com.github.prgrms.orders;

import com.github.prgrms.review.Review;
import com.github.prgrms.review.ReviewResult;

import java.time.LocalDateTime;

public class OrderResult {

    private final long seq;
    private final long productId;
    private final ReviewResult review;
    private final String state;
    private final String requestMessage;
    private final String rejectMessage;
    private final LocalDateTime completedAt;
    private final LocalDateTime rejectedAt;
    private final LocalDateTime createAt;

    public OrderResult(long seq, long productId, ReviewResult review, String state, String requestMessage, String rejectMessage, LocalDateTime completedAt, LocalDateTime rejectedAt, LocalDateTime createAt) {
        this.seq = seq;
        this.productId = productId;
        this.review = review;
        this.state = state;
        this.requestMessage = requestMessage;
        this.rejectMessage = rejectMessage;
        this.completedAt = completedAt;
        this.rejectedAt = rejectedAt;
        this.createAt = createAt;
    }

    public OrderResult(Order order, Review review) {
        this.seq = order.getSeq();
        this.productId = order.getProductSeq();
        this.review = review == null ? null : new ReviewResult(review);
        this.state = order.getState().getState();
        this.requestMessage = order.getRequestMsg();
        this.rejectMessage = order.getRejectMsg();
        this.completedAt = order.getCompletedAt();
        this.rejectedAt = order.getRejectedAt();
        this.createAt = order.getCreateAt();
    }

    public long getSeq() {
        return seq;
    }

    public long getProductId() {
        return productId;
    }

    public ReviewResult getReview() {
        return review;
    }

    public String getState() {
        return state;
    }

    public String getRequestMessage() {
        return requestMessage;
    }

    public String getRejectMessage() {
        return rejectMessage;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public LocalDateTime getRejectedAt() {
        return rejectedAt;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    @Override
    public String toString() {
        return "OrderResult{" +
                "seq=" + seq +
                ", productId=" + productId +
                ", review=" + review +
                ", state='" + state + '\'' +
                ", requestMessage='" + requestMessage + '\'' +
                ", rejectMessage='" + rejectMessage + '\'' +
                ", completedAt=" + completedAt +
                ", rejectedAt=" + rejectedAt +
                ", createAt=" + createAt +
                '}';
    }
}
