package com.github.prgrms.review;

import java.time.LocalDateTime;

public class ReviewResult {
    private final long seq;
    private final long productId;
    private final String content;
    private final LocalDateTime createAt;

    public ReviewResult(Review review) {
        this.seq = review.getSeq();
        this.productId = review.getProductSeq();
        this.content = review.getContent();
        this.createAt = review.getCreateAt();
    }

    public long getSeq() {
        return seq;
    }

    public long getProductId() {
        return productId;
    }

    public String getContent() {
        return content;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    @Override
    public String toString() {
        return "ReviewResult{" +
                "seq='" + seq + '\'' +
                ", productId=" + productId +
                ", content='" + content + '\'' +
                ", createAt=" + createAt +
                '}';
    }
}
