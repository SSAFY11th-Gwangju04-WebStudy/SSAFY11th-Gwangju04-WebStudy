package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static java.util.Optional.ofNullable;

@Repository
public class JdbcOrderRepository implements OrderRepository {

    private final JdbcTemplate jdbcTemplate;

    public JdbcOrderRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void update(Order order) {
        jdbcTemplate.update(
                "update orders set review_seq=?, state=?, request_msg=?, reject_msg=?, completed_at=?, rejected_at=? where seq=?",
                order.getReviewSeq(),
                order.getState().getState(),
                order.getRequestMsg(),
                order.getRejectMsg(),
                order.getCompletedAt(),
                order.getRejectedAt(),
                order.getSeq()
        );
    }

    @Override
    public Optional<Order> findById(long id) {
        List<Order> results = jdbcTemplate.query("select * from orders where seq = ?", mapper, id);
        return ofNullable(results.isEmpty() ? null : results.get(0));
    }

    @Override
    public List<Order> findAll(Pageable pageable, long userId) {
        return jdbcTemplate.query("select * from orders where user_seq = ? order by seq desc limit ?, ? ",
                mapper,
                userId,
                pageable.getOffset(),
                pageable.getSize());
    }

    static RowMapper<Order> mapper = (rs, rowNum) ->
            new Order(
                    rs.getLong("seq"),
                    rs.getLong("user_seq"),
                    rs.getLong("product_seq"),
                    rs.getObject("review_seq") == null ? null : rs.getLong("review_seq"),
                    OrderState.of(rs.getString("state")),
                    rs.getString("request_msg"),
                    rs.getString("reject_msg"),
                    rs.getTimestamp("completed_at"),
                    rs.getTimestamp("rejected_at"),
                    rs.getTimestamp("create_at")
            );
}
