package com.github.prgrms.review;

import com.github.prgrms.errors.NotFoundException;
import com.github.prgrms.errors.ReviewNotAllowedException;
import com.github.prgrms.orders.Order;
import com.github.prgrms.orders.OrderRepository;
import com.github.prgrms.orders.OrderState;
import com.github.prgrms.products.ProductRepository;
import org.springframework.stereotype.Service;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;

    public ReviewService(ReviewRepository reviewRepository, OrderRepository orderRepository, ProductRepository productRepository) {
        this.reviewRepository = reviewRepository;
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    public Review createReview(long orderId, long userId, String reviewContent) {
        Order order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));

        long productId = order.getProductSeq();

        if (reviewContent == null || reviewContent.isEmpty()) {
            throw new ReviewNotAllowedException("Review content is empty");
        }

        if (reviewContent.length() > 1000) {
            throw new ReviewNotAllowedException("Review content too long");
        }

        if (order.getState() != OrderState.COMPLETED) {
            throw new ReviewNotAllowedException("Could not write review for order "
                    + orderId + " because state(" + order.getState().getState() + ") is not allowed");
        }

        if (order.getReviewSeq() != null) {
            System.out.println(order.getReviewSeq());
            throw new ReviewNotAllowedException("Could not write review for order "
                    + orderId + " because have already written");
        }

        Review reviewData = new Review(reviewContent, productId, userId);
        reviewRepository.saveReview(reviewData);

        System.out.println(reviewContent);

        Review saveData = reviewRepository.findByUserIdAndProductId(userId, productId).orElseThrow(() -> new NotFoundException("Review not found"));

        productRepository.updateReviewCount(productId);

        order.writeReviewSuccess(saveData.getSeq());
        orderRepository.update(order);

        return saveData;
    }
}
