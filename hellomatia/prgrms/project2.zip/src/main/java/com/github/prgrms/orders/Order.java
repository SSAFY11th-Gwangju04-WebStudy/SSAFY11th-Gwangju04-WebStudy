package com.github.prgrms.orders;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Objects;

public class Order {

    private Long seq;
    private Long userSeq;
    private Long productSeq;
    private Long reviewSeq;
    private OrderState state;
    private String requestMsg;
    private String rejectMsg;
    private LocalDateTime completedAt;
    private LocalDateTime rejectedAt;
    private LocalDateTime createAt;

    public Order() {
    }

    public Order(Long seq, Long userSeq, Long productSeq, Long reviewSeq, OrderState state, String requestMsg, String rejectMsg, LocalDateTime completedAt, LocalDateTime rejectedAt, LocalDateTime createAt) {
        this.seq = seq;
        this.userSeq = userSeq;
        this.productSeq = productSeq;
        this.reviewSeq = reviewSeq;
        this.state = state;
        this.requestMsg = requestMsg;
        this.rejectMsg = rejectMsg;
        this.completedAt = completedAt;
        this.rejectedAt = rejectedAt;
        this.createAt = createAt;
    }

    public Order(Long seq, Long userSeq, Long productSeq, Long reviewSeq, OrderState state, String requestMsg, String rejectMsg, Timestamp completedAt, Timestamp rejectedAt, Timestamp createAt) {
        this.seq = seq;
        this.userSeq = userSeq;
        this.productSeq = productSeq;
        this.reviewSeq = reviewSeq;
        this.state = state;
        this.requestMsg = requestMsg;
        this.rejectMsg = rejectMsg;
        setCompletedAt(completedAt);
        setRejectedAt(rejectedAt);
        setCreateAt(createAt);
    }

    public Long getSeq() {
        return seq;
    }

    public void setSeq(Long seq) {
        this.seq = seq;
    }

    public Long getUserSeq() {
        return userSeq;
    }

    public void setUserSeq(Long userSeq) {
        this.userSeq = userSeq;
    }

    public Long getProductSeq() {
        return productSeq;
    }

    public void setProductSeq(Long productSeq) {
        this.productSeq = productSeq;
    }

    public Long getReviewSeq() {
        return reviewSeq;
    }

    public void setReviewSeq(Long reviewSeq) {
        this.reviewSeq = reviewSeq;
    }

    public OrderState getState() {
        return state;
    }

    public void setState(OrderState state) {
        this.state = state;
    }

    public String getRequestMsg() {
        return requestMsg;
    }

    public void setRequestMsg(String requestMsg) {
        this.requestMsg = requestMsg;
    }

    public String getRejectMsg() {
        return rejectMsg;
    }

    public void setRejectMsg(String rejectMsg) {
        this.rejectMsg = rejectMsg;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Timestamp completedAt) {
        if (completedAt == null) {
            return;
        }
        this.completedAt = completedAt.toLocalDateTime();
    }

    public LocalDateTime getRejectedAt() {
        return rejectedAt;
    }

    public void setRejectedAt(Timestamp rejectedAt) {
        if (rejectedAt == null) {
            return;
        }
        this.rejectedAt = rejectedAt.toLocalDateTime();
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Timestamp createAt) {
        if (createAt == null) {
            return;
        }
        this.createAt = createAt.toLocalDateTime();
    }

    public void writeReviewSuccess(long reviewId) {
        reviewSeq = reviewId;
    }

    public void rejectSuccess(String rejectMsg) {
        this.rejectMsg = rejectMsg;
        rejectedAt = LocalDateTime.now();
    }

    public void completedSuccess() {
        this.state = OrderState.COMPLETED;
        completedAt = LocalDateTime.now();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return Objects.equals(seq, order.seq) && Objects.equals(userSeq, order.userSeq) && Objects.equals(productSeq, order.productSeq) && Objects.equals(reviewSeq, order.reviewSeq) && state == order.state && Objects.equals(requestMsg, order.requestMsg) && Objects.equals(rejectMsg, order.rejectMsg) && Objects.equals(completedAt, order.completedAt) && Objects.equals(rejectedAt, order.rejectedAt) && Objects.equals(createAt, order.createAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(seq, userSeq, productSeq, reviewSeq, state, requestMsg, rejectMsg, completedAt, rejectedAt, createAt);
    }

    @Override
    public String toString() {
        return "Order{" +
                "seq=" + seq +
                ", userSeq=" + userSeq +
                ", productSeq=" + productSeq +
                ", reviewSeq=" + reviewSeq +
                ", state=" + state +
                ", requestMsg='" + requestMsg + '\'' +
                ", rejectMsg='" + rejectMsg + '\'' +
                ", completedAt=" + completedAt +
                ", rejectedAt=" + rejectedAt +
                ", createAt=" + createAt +
                '}';
    }
}
