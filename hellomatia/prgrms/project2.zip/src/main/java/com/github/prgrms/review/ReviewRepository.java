package com.github.prgrms.review;

import java.util.Optional;

public interface ReviewRepository {
    int saveReview(Review review);

    Optional<Review> findByUserIdAndProductId(long userId, long productId);

    Optional<Review> findById(long reviewId);
}
