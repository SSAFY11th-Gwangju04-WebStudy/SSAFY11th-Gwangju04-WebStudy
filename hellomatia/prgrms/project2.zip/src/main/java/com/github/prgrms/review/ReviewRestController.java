package com.github.prgrms.review;

import com.github.prgrms.security.JwtAuthentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.github.prgrms.utils.ApiUtils.ApiResult;
import static com.github.prgrms.utils.ApiUtils.success;

@RestController
@RequestMapping("api/orders")
public class ReviewRestController {

    private final ReviewService reviewService;

    public ReviewRestController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @PostMapping("/{orderId}/review")
    public ApiResult<ReviewResult> review(@PathVariable long orderId,
                                          @RequestBody Map<String, String> requestBody,
                                          @AuthenticationPrincipal JwtAuthentication authentication) {

        Review review = reviewService.createReview(orderId,
                authentication.id,
                requestBody.get("content"));
        return success(new ReviewResult(review));
    }

}
