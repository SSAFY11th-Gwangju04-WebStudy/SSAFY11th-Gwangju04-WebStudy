package com.github.prgrms.orders;

import com.github.prgrms.configures.web.Pageable;

import java.util.List;
import java.util.Optional;

public interface OrderRepository {

    void update(Order order);

    Optional<Order> findById(long id);

    List<Order> findAll(Pageable pageable, long userId);

}
